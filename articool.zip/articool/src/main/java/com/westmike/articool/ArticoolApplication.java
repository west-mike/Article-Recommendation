package com.westmike.articool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArticoolApplication.class, args);
	}

}
