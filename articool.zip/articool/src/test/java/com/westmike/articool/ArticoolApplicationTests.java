package com.westmike.articool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
